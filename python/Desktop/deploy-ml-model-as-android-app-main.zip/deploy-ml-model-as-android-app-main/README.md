# deploy-ml-model-as-android-app
Code to deploy ML model as an Android App
